var files_dup =
[
    [ "Controller.py", "Controller_8py.html", [
      [ "ClosedLoopDriver", "classController_1_1ClosedLoopDriver.html", "classController_1_1ClosedLoopDriver" ]
    ] ],
    [ "cotask.py", "cotask_8py.html", "cotask_8py" ],
    [ "imu.py", "imu_8py.html", "imu_8py" ],
    [ "main.py", "main_8py.html", "main_8py" ],
    [ "mainpage.py", "mainpage_8py.html", null ],
    [ "MotorDriver.py", "MotorDriver_8py.html", [
      [ "MotorDriver", "classMotorDriver_1_1MotorDriver.html", "classMotorDriver_1_1MotorDriver" ]
    ] ],
    [ "print_task.py", "print__task_8py.html", "print__task_8py" ],
    [ "task_share.py", "task__share_8py.html", "task__share_8py" ],
    [ "vector3d.py", "vector3d_8py.html", "vector3d_8py" ]
];