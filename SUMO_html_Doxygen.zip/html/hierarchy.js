var hierarchy =
[
    [ "Controller.ClosedLoopDriver", "classController_1_1ClosedLoopDriver.html", null ],
    [ "Encoder.EncoderDriver", "classEncoder_1_1EncoderDriver.html", null ],
    [ "MotorDriver.MotorDriver", "classMotorDriver_1_1MotorDriver.html", null ],
    [ "necir.NecIr", "classnecir_1_1NecIr.html", null ],
    [ "object", null, [
      [ "imu.MPU6050", "classimu_1_1MPU6050.html", null ],
      [ "vector3d.Vector3d", "classvector3d_1_1Vector3d.html", null ]
    ] ],
    [ "OSError", null, [
      [ "imu.MPUException", "classimu_1_1MPUException.html", null ]
    ] ],
    [ "task_share.Queue", "classtask__share_1_1Queue.html", null ],
    [ "RuntimeError", null, [
      [ "VL53L0X.TimeoutError", "classVL53L0X_1_1TimeoutError.html", null ]
    ] ],
    [ "task_share.Share", "classtask__share_1_1Share.html", null ],
    [ "cotask.Task", "classcotask_1_1Task.html", null ],
    [ "cotask.TaskList", "classcotask_1_1TaskList.html", null ],
    [ "VL53L0X.VL53L0X", "classVL53L0X_1_1VL53L0X.html", null ]
];