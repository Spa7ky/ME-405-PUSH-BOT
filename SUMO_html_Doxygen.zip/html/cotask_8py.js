var cotask_8py =
[
    [ "Task", "classcotask_1_1Task.html", "classcotask_1_1Task" ],
    [ "TaskList", "classcotask_1_1TaskList.html", "classcotask_1_1TaskList" ],
    [ "task_list", "cotask_8py.html#ae54e25f8d14958f642bcc22ddeb6c56f", null ]
];