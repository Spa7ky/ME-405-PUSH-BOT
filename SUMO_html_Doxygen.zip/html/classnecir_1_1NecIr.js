var classnecir_1_1NecIr =
[
    [ "__init__", "classnecir_1_1NecIr.html#a70a0591ac1e2d8da30a9202195878750", null ],
    [ "callback", "classnecir_1_1NecIr.html#a8abcabfe0927409838352a1258f8228d", null ]
];