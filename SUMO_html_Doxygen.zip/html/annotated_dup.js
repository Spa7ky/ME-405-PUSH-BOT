var annotated_dup =
[
    [ "Controller", null, [
      [ "ClosedLoopDriver", "classController_1_1ClosedLoopDriver.html", "classController_1_1ClosedLoopDriver" ]
    ] ],
    [ "cotask", null, [
      [ "Task", "classcotask_1_1Task.html", "classcotask_1_1Task" ],
      [ "TaskList", "classcotask_1_1TaskList.html", "classcotask_1_1TaskList" ]
    ] ],
    [ "Encoder", null, [
      [ "EncoderDriver", "classEncoder_1_1EncoderDriver.html", "classEncoder_1_1EncoderDriver" ]
    ] ],
    [ "imu", null, [
      [ "MPU6050", "classimu_1_1MPU6050.html", "classimu_1_1MPU6050" ],
      [ "MPUException", "classimu_1_1MPUException.html", null ]
    ] ],
    [ "MotorDriver", null, [
      [ "MotorDriver", "classMotorDriver_1_1MotorDriver.html", "classMotorDriver_1_1MotorDriver" ]
    ] ],
    [ "necir", null, [
      [ "NecIr", "classnecir_1_1NecIr.html", "classnecir_1_1NecIr" ]
    ] ],
    [ "task_share", null, [
      [ "Queue", "classtask__share_1_1Queue.html", "classtask__share_1_1Queue" ],
      [ "Share", "classtask__share_1_1Share.html", "classtask__share_1_1Share" ]
    ] ],
    [ "vector3d", null, [
      [ "Vector3d", "classvector3d_1_1Vector3d.html", "classvector3d_1_1Vector3d" ]
    ] ],
    [ "VL53L0X", null, [
      [ "TimeoutError", "classVL53L0X_1_1TimeoutError.html", null ],
      [ "VL53L0X", "classVL53L0X_1_1VL53L0X.html", "classVL53L0X_1_1VL53L0X" ]
    ] ]
];