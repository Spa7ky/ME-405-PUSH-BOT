var searchData=
[
  ['necir',['NecIr',['../classnecir_1_1NecIr.html',1,'necir']]]
];
