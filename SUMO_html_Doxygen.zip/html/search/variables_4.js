var searchData=
[
  ['kppos',['KpPos',['../classController_1_1ClosedLoopDriver.html#ad7bab039788ebfba0413f867be71acb2',1,'Controller::ClosedLoopDriver']]],
  ['kpvel',['KpVel',['../classController_1_1ClosedLoopDriver.html#a0ab4e5ac6116c07af675726291f42f91',1,'Controller::ClosedLoopDriver']]]
];
