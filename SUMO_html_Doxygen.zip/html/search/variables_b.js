var searchData=
[
  ['vel_5fsetpoint',['Vel_setpoint',['../classController_1_1ClosedLoopDriver.html#a976a49b120e71862135c8f99b5553cb3',1,'Controller::ClosedLoopDriver']]]
];
