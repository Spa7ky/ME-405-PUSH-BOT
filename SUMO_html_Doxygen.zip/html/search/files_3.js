var searchData=
[
  ['print_5ftask_2epy',['print_task.py',['../print__task_8py.html',1,'']]]
];
