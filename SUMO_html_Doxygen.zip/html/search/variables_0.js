var searchData=
[
  ['buf_5fsize',['BUF_SIZE',['../print__task_8py.html#a88f04f8dbccfe4f94fc04afbc194a7b0',1,'print_task']]]
];
