var searchData=
[
  ['task_5fshare_2epy',['task_share.py',['../task__share_8py.html',1,'']]]
];
