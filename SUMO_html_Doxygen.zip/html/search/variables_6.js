var searchData=
[
  ['name',['name',['../classcotask_1_1Task.html#ab54e069dd0b4f0a2f8e7f00c94998a10',1,'cotask::Task']]]
];
