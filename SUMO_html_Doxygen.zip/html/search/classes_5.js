var searchData=
[
  ['share',['Share',['../classtask__share_1_1Share.html',1,'task_share']]]
];
