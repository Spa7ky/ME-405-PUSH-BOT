var searchData=
[
  ['name',['name',['../classcotask_1_1Task.html#ab54e069dd0b4f0a2f8e7f00c94998a10',1,'cotask::Task']]],
  ['necir',['NecIr',['../classnecir_1_1NecIr.html',1,'necir']]],
  ['num_5fin',['num_in',['../classtask__share_1_1Queue.html#a713321bacac5d93ecf89c4be1c15fe30',1,'task_share::Queue']]]
];
