var searchData=
[
  ['go_5fflag',['go_flag',['../classcotask_1_1Task.html#a96733bb9f4349a3f284083d1d4e64f9f',1,'cotask::Task']]]
];
