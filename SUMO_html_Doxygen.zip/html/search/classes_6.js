var searchData=
[
  ['task',['Task',['../classcotask_1_1Task.html',1,'cotask']]],
  ['tasklist',['TaskList',['../classcotask_1_1TaskList.html',1,'cotask']]],
  ['timeouterror',['TimeoutError',['../classVL53L0X_1_1TimeoutError.html',1,'VL53L0X']]]
];
