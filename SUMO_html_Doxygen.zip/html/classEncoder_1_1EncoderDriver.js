var classEncoder_1_1EncoderDriver =
[
    [ "__init__", "classEncoder_1_1EncoderDriver.html#aa01d5c8b9d6df4eff7867dcc6776b4b4", null ],
    [ "Position", "classEncoder_1_1EncoderDriver.html#a27002e4c2aec19c692327d1d9b1c99f2", null ],
    [ "read", "classEncoder_1_1EncoderDriver.html#a835f90a503bc3c18caa7ed938a017b69", null ],
    [ "Velocity", "classEncoder_1_1EncoderDriver.html#aa4cf56b4022fe6984f9a8c6f310f478e", null ],
    [ "zero", "classEncoder_1_1EncoderDriver.html#a45d43abb78ceb043d7df4f89c43b2b98", null ],
    [ "direction", "classEncoder_1_1EncoderDriver.html#aae3f8f4546c50111318c214f10eb96c1", null ],
    [ "encNew", "classEncoder_1_1EncoderDriver.html#abad72dc6fa77785fa1e096f0be6457e4", null ],
    [ "encPin1", "classEncoder_1_1EncoderDriver.html#a4ace52fb24f65f7190c828e646a69ddd", null ],
    [ "encPin2", "classEncoder_1_1EncoderDriver.html#a60fbc4dbc09b5067bf7b41b3214d8f6b", null ],
    [ "enctimer", "classEncoder_1_1EncoderDriver.html#a1e6762102d0191be76b12eec3212a81c", null ],
    [ "encTimerCh1", "classEncoder_1_1EncoderDriver.html#ad53b88faeb55434eff19b7b4bfbd9fcb", null ],
    [ "encTimerCh2", "classEncoder_1_1EncoderDriver.html#a3a226d7729531bf064098a89e89a6c78", null ],
    [ "encTotal", "classEncoder_1_1EncoderDriver.html#ae5a874604f11f7a7fe111c4d969e1ddb", null ]
];